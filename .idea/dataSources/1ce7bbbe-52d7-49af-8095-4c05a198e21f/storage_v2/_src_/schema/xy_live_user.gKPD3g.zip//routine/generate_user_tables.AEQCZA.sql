create
    definer = root@`%` procedure generate_user_tables()
BEGIN
    DECLARE i INT DEFAULT 0;
    WHILE i < 100 DO
            -- 生成表名（补两位前缀，如00、01...99）
            SET @table_name = CONCAT('t_user_', LPAD(i, 2, '0'));
            -- 动态SQL插入数据（修正引号转义）
            SET @sql = CONCAT(
                    'INSERT INTO ', @table_name, ' (user_id, nick_name, avatar, true_name, sex, born_date, work_city, born_city, create_time, update_time)
            SELECT
                10000 + (t.rownum * 100) + ', i, ' AS user_id,
                CONCAT(\'星跃用户_\', 10000 + (t.rownum * 100) + ', i, ') AS nick_name,
                CONCAT(\'https://avatar.xy.com/u\', 10000 + (t.rownum * 100) + ', i, '\'.jpg\') AS avatar,
                CONCAT(\'用户\', LPAD(10000 + (t.rownum * 100) + ', i, ', 8, ''0'')) AS true_name,
                FLOOR(RAND() * 2) AS sex,
                DATE_SUB(CURDATE(), INTERVAL FLOOR(RAND() * 365 * 50) DAY) AS born_date,
                FLOOR(RAND() * 65535) AS work_city,
                FLOOR(RAND() * 65535) AS born_city,
                NOW() AS create_time,
                NOW() AS update_time
            FROM (
                SELECT @rownum := @rownum + 1 AS rownum
                FROM information_schema.columns, (SELECT @rownum := 0) r
                LIMIT 1000
            ) t;'
                       );
            PREPARE stmt FROM @sql;
            EXECUTE stmt;
            DEALLOCATE PREPARE stmt;
            SET i = i + 1;
        END WHILE;
END;

